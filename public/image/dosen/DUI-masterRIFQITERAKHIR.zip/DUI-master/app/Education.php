<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Education;

class Education extends Model
{

	public $timestamps = false;

    protected $table = "Education";
}
