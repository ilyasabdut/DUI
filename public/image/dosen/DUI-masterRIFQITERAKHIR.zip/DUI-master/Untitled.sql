-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: webTI
-- ------------------------------------------------------
-- Server version	5.6.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AchievementDosen`
--

DROP TABLE IF EXISTS `AchievementDosen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AchievementDosen` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NIDN` varchar(25) NOT NULL,
  `Nama` varchar(25) NOT NULL,
  `Prestasi` text NOT NULL,
  `Tanggal` date NOT NULL,
  `Keterangan` text NOT NULL,
  PRIMARY KEY (`NIDN`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `AchievementMhs`
--

DROP TABLE IF EXISTS `AchievementMhs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AchievementMhs` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NPM` varchar(25) NOT NULL,
  `Nama` varchar(25) NOT NULL,
  `Prestasi` text NOT NULL,
  `Tanggal` date NOT NULL,
  `Keterangan` text NOT NULL,
  PRIMARY KEY (`NPM`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Alumni`
--

DROP TABLE IF EXISTS `Alumni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Alumni` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NPM` varchar(20) NOT NULL DEFAULT '',
  `Nama` varchar(50) DEFAULT NULL,
  `Pembimbing` varchar(50) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL,
  `Penguji` varchar(50) DEFAULT NULL,
  `Judul` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NPM`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DedicationDosen`
--

DROP TABLE IF EXISTS `DedicationDosen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DedicationDosen` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NIDN` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Tempat` varchar(30) NOT NULL,
  `Jenis` varchar(30) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL,
  PRIMARY KEY (`NIDN`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DedicationMhs`
--

DROP TABLE IF EXISTS `DedicationMhs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DedicationMhs` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NPM` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Tempat` varchar(30) DEFAULT NULL,
  `Jenis` varchar(30) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL,
  PRIMARY KEY (`NPM`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Dosen`
--

DROP TABLE IF EXISTS `Dosen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dosen` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NIDN` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NIDN`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Education`
--

DROP TABLE IF EXISTS `Education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Education` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `Judul` varchar(50) NOT NULL,
  `Isi` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Mahasiswa`
--

DROP TABLE IF EXISTS `Mahasiswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mahasiswa` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NPM` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NPM`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `News`
--

DROP TABLE IF EXISTS `News`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `News` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `Judul` varchar(30) NOT NULL,
  `Isi` text NOT NULL,
  `Tag` varchar(30) NOT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PublicationDosen`
--

DROP TABLE IF EXISTS `PublicationDosen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PublicationDosen` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NIDN` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Judul` varchar(30) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL,
  `Keterangan` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NIDN`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PublicationMhs`
--

DROP TABLE IF EXISTS `PublicationMhs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PublicationMhs` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NPM` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Judul` varchar(30) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL,
  `Keterangan` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NPM`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ResearchDosen`
--

DROP TABLE IF EXISTS `ResearchDosen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResearchDosen` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NIDN` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Judul` varchar(50) NOT NULL,
  `Tanggal` date DEFAULT NULL,
  `Jenis` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NIDN`),
  UNIQUE KEY `ID` (`ID`),
  CONSTRAINT `researchdosen_ibfk_1` FOREIGN KEY (`NIDN`) REFERENCES `Dosen` (`NIDN`),
  CONSTRAINT `researchdosen_ibfk_2` FOREIGN KEY (`NIDN`) REFERENCES `Dosen` (`NIDN`),
  CONSTRAINT `researchdosen_ibfk_3` FOREIGN KEY (`NIDN`) REFERENCES `Dosen` (`NIDN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ResearchMhs`
--

DROP TABLE IF EXISTS `ResearchMhs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResearchMhs` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `NPM` varchar(12) NOT NULL DEFAULT '',
  `Nama` varchar(30) DEFAULT NULL,
  `Judul` varchar(50) NOT NULL,
  `Tanggal` date DEFAULT NULL,
  `Jenis` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NPM`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rememberToken` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partnership`
--

DROP TABLE IF EXISTS `partnership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partnership` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `Partner` varchar(30) NOT NULL DEFAULT '',
  `Program` varchar(30) DEFAULT NULL,
  `Jenis` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-06 13:54:35
